                                                                              
                                                   *********** CFILT Hindi POS Tagger***********




>This POS tagger is developed at the CFILT department of Indian Institute Of Technology, Bombay, India.

>This is a CRF based POS Tagger for Hindi Language. This tagger uses CRF based open source tool-kit CRF++. 
 You can get the CRF++ tool-kit from- http://crfpp.sourceforge.net/

>CRF++ tool-kit is used to POS tag the input text. Text Files  can't be used directly for testing using the CRF++ package. 

>Instruction to install the tagger are in INSTALL.txt. 

>Following are the  instructions to get the input text POS tagged.
 Suppose path of the extracted system is -"/home/user1/Desktop/Hindi_POStagger/".

  Step1 : Input text(test_file.txt) is first tokenized. Run-

          :~$sh /home/user1/Desktop/Hindi_POStagger/tokenize.sh test_file.txt > file1.txt

  Step1 : To form the file that can be used as an input to the CRF, "FileFormer.java" in the directory  Hindi_POStagger/src/iitb/cfilt/cpost/crfpp/ is used.
          -For this following 3 arguments are required:
           i)config file
           ii)Input tokenized Text file(in previous step)  say file1.txt
           iii)Path of the new file for input to CRF++ say file2.txt. 

           i.e. go to the "/home/user1/Desktop/Hindi_POStagger/src/" directory and run the following command-

           :~$java  iitb.cfilt.cpost.crfpp.FileFormer  /home/user1/Desktop/Hindi_POStagger/HindiLinguisticResources/hindiConfig  ../file1.txt ../file2.txt

 Step2 : Test this file2.txt on CRF++, go to the directory where CRF++(e.g. CRF++-0.50) is installed and run-

          :~$ /CRF++-0.50/crf_test -m /home/user1/Desktop/Hindi_POStagger/CRF_modelfile/model_file /home/user1/Desktop/Hindi_POStagger/file2.txt > /home/user1/Desktop/Hindi_POStagger/result.txt
           Final columns of each line of this file is the POS tag given by the CRF.

 Step3 : Go to "/home/user1/Desktop/Hindi_POStagger/"  and run-
          :~$awk -f Tossf.awk result.txt > POS_Tagged.txt

         -POS_Tagged.txt file contains the POS tagged text in SSF format. 
         -If you do not want output in SSF format, you can process result.txt file, first column of every line is the word, and last column of this line 
          is POS tag given by the CRF.

****************************************************************END******************************************************************************************

