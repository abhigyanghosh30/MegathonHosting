# This a tokenizer, converts each word to word_[ NN ]. This NN tag is just an intial tag, it doesnt play any role.


awk -f tokenize.awk  $1 > inputFIle1.txt
awk 'sub(/\r/,""){print $0;next}{print}' inputFIle1.txt > inputFIle2.txt
awk 'sub(/^_\[ NN \]/,""){print $0;next}{print}' inputFIle2.txt 

rm inputFIle1.txt
rm inputFIle2.txt
